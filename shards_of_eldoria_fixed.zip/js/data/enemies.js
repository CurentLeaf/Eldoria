const ENEMIES = {
    forest_wolf: {
        id: 'forest_wolf', name: 'Starving Wolf', icon: '🐺', level: 2,
        description: 'Hunger has driven it to madness.',
        stats: { health: 30, maxHealth: 30, strength: 5, defense: 1, agility: 7 },
        xpReward: 20, goldReward: { min: 0, max: 5 },
        loot: []
    },
    goblin_scout: {
        id: 'goblin_scout', name: 'Goblin Scout', icon: '👺', level: 2,
        description: 'Small, cowardly, dangerous in groups.',
        stats: { health: 25, maxHealth: 25, strength: 4, defense: 1, agility: 6 },
        xpReward: 18, goldReward: { min: 3, max: 12 },
        loot: []
    },
    goblin_warrior: {
        id: 'goblin_warrior', name: 'Goblin Warrior', icon: '👹', level: 4,
        description: 'Armored and angry.',
        stats: { health: 45, maxHealth: 45, strength: 7, defense: 4, agility: 4 },
        xpReward: 35, goldReward: { min: 8, max: 20 },
        loot: []
    },
    goblin_chieftain: {
        id: 'goblin_chieftain', name: 'Grimjaw the Chieftain', icon: '👑', level: 8,
        description: 'The tyrant of the goblin tribes.',
        stats: { health: 200, maxHealth: 200, strength: 12, defense: 8, agility: 5 },
        xpReward: 250, goldReward: { min: 80, max: 120 },
        loot: [],
        isBoss: true
    }
};

const DEATH_MESSAGES = [
    'Your vision fades to black. The darkness claims another.',
    'Blood pools beneath you. Your story ends here.',
    'The pain stops. Everything stops.',
    'Death comes not as an enemy, but as a release.'
];
