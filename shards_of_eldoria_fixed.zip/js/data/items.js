const ITEMS = {
    health_potion: {
        id: 'health_potion', name: 'Health Potion', type: 'consumable', icon: '🧪',
        description: 'Restores 30 HP',
        effect: { heal: 30 }, value: 15, stackable: true, maxStack: 20
    },
    bread: {
        id: 'bread', name: 'Stale Bread', type: 'consumable', icon: '🍞',
        description: 'Restores 8 HP',
        effect: { heal: 8 }, value: 3, stackable: true, maxStack: 20
    },
    leather_armor: {
        id: 'leather_armor', name: 'Leather Armor', type: 'armor', icon: '🥋',
        description: 'Basic protection',
        stats: { defense: 3 }, value: 20, rarity: 'COMMON'
    },
    mage_robes: {
        id: 'mage_robes', name: 'Mage Robes', type: 'armor', icon: '🧥',
        description: 'Enchanted fabric',
        stats: { defense: 2, intelligence: 5 }, value: 150, rarity: 'UNCOMMON'
    },
    shadow_cloak: {
        id: 'shadow_cloak', name: 'Shadow Cloak', type: 'armor', icon: '🦇',
        description: 'Woven from darkness',
        stats: { defense: 5, agility: 4 }, value: 200, rarity: 'RARE'
    }
};

const CLASS_EQUIPMENT = {
    warrior: {
        weapon: 'rusty_sword',
        armor: 'leather_armor',
        items: ['health_potion', 'health_potion', 'bread']
    },
    mage: {
        weapon: 'wooden_staff',
        armor: 'mage_robes',
        items: ['health_potion', 'health_potion']
    },
    rogue: {
        weapon: 'hunting_knife',
        armor: 'shadow_cloak',
        items: ['health_potion', 'bread']
    }
};

const SHOP_INVENTORIES = {
    millbrook: {
        name: 'Millbrook Shop',
        items: [
            { id: 'health_potion', price: 15, stock: 10 },
            { id: 'bread', price: 3, stock: 20 }
        ]
    }
};
