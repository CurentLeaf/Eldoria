const QUESTS = {
    main_awakening: {
        id: 'main_awakening',
        title: 'The Awakening',
        type: 'main',
        act: 1,
        description: 'You awaken in darkness with fragmented memories.',
        objectives: [
            { id: 'wake_up', text: 'Regain consciousness', completed: false },
            { id: 'reach_village', text: 'Reach Millbrook village', completed: false }
        ],
        rewards: { xp: 50, gold: 0 },
        nextQuest: 'main_village_in_flames'
    },
    main_village_in_flames: {
        id: 'main_village_in_flames',
        title: 'Village in Flames',
        type: 'main',
        act: 1,
        description: 'Millbrook burns. Goblins have attacked.',
        objectives: [
            { id: 'speak_elder', text: 'Speak with Elder Mira', completed: false },
            { id: 'defeat_goblins', text: 'Defeat the goblins', completed: false }
        ],
        rewards: { xp: 75, gold: 25 }
    }
};
