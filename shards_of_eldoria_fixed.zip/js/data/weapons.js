const WEAPONS = {
    rusty_sword: {
        id: 'rusty_sword', name: 'Rusty Sword', type: 'SWORD', icon: '🗡️',
        damage: 5, rarity: 'COMMON',
        description: 'A blade caked in rust and old blood. It will do.',
        enhancements: [], maxEnhancements: 2
    },
    wooden_staff: {
        id: 'wooden_staff', name: 'Gnarled Staff', type: 'STAFF', icon: '🪄',
        damage: 4, rarity: 'COMMON',
        stats: { intelligence: 2 },
        description: 'A twisted branch that hums with latent power.',
        enhancements: [], maxEnhancements: 2
    },
    hunting_knife: {
        id: 'hunting_knife', name: 'Hunting Knife', type: 'DAGGER', icon: '🔪',
        damage: 3, rarity: 'COMMON',
        stats: { agility: 1 },
        description: 'Sharp and quick. Made for skinning prey.',
        enhancements: [], maxEnhancements: 2
    },
    soldier_sword: {
        id: 'soldier_sword', name: 'Soldier\'s Blade', type: 'SWORD', icon: '⚔️',
        damage: 9, rarity: 'UNCOMMON',
        description: 'Standard military issue.',
        enhancements: [], maxEnhancements: 3
    }
};
