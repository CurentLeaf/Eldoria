class Character {
    constructor(name, characterClass, difficulty) {
        this.name = name;
        this.characterClass = characterClass;
        this.difficulty = difficulty || 'normal';
        this.level = 1;
        this.xp = 0;
        this.xpToLevel = 100;
        this.gold = 30;
        this.karma = 0;

        this.baseStats = {
            maxHealth: 60,
            health: 60,
            strength: 5,
            intelligence: 5,
            agility: 5,
            luck: 5,
            vitality: 5,
            defense: 0
        };

        this.applyClassBonuses();

        this.equipment = {
            weapon: null,
            armor: null,
            accessory: null
        };

        this.inventory = [];
        this.maxInventory = 20;

        this.skills = this.getStartingSkills();
        this.statusEffects = [];
        this.specialCooldown = 0;

        this.flags = {};
        this.questProgress = {};
        this.killedEnemies = {};
        this.totalKills = 0;
        this.deaths = 0;
    }

    applyClassBonuses() {
        const bonuses = {
            warrior: { strength: 4, vitality: 3, maxHealth: 20 },
            mage: { intelligence: 4, luck: 2, maxHealth: -10 },
            rogue: { agility: 4, luck: 2, maxHealth: 0 }
        };

        const classBonus = bonuses[this.characterClass];
        if (classBonus) {
            for (let stat in classBonus) {
                this.baseStats[stat] = (this.baseStats[stat] || 0) + classBonus[stat];
            }
            this.baseStats.health = this.baseStats.maxHealth;
        }
    }

    getStartingSkills() {
        const skills = {
            warrior: {
                active: { id: 'brutal_strike', name: 'Brutal Strike', damage: 1.8, cooldown: 3 }
            },
            mage: {
                active: { id: 'soul_burn', name: 'Soul Burn', damage: 2.0, cooldown: 3 }
            },
            rogue: {
                active: { id: 'throat_slit', name: 'Throat Slit', damage: 2.5, cooldown: 2 }
            }
        };
        return skills[this.characterClass] || skills.warrior;
    }

    getEffectiveStat(stat) {
        let value = this.baseStats[stat] || 0;

        for (let slot in this.equipment) {
            const itemId = this.equipment[slot];
            if (itemId) {
                const item = ITEMS[itemId] || WEAPONS[itemId];
                if (item && item.stats && item.stats[stat]) {
                    value += item.stats[stat];
                }
            }
        }

        return Math.max(0, value);
    }

    addXP(amount) {
        this.xp += amount;
        if (this.xp >= this.xpToLevel) {
            this.xp -= this.xpToLevel;
            this.level++;
            this.xpToLevel = Math.floor(this.xpToLevel * 1.4);
            this.baseStats.maxHealth += 8;
            this.baseStats.health = this.baseStats.maxHealth;
            return { leveledUp: true, newLevel: this.level };
        }
        return { leveledUp: false };
    }

    takeDamage(amount) {
        const defense = this.getEffectiveStat('defense');
        let actualDamage = Math.max(1, amount - Math.floor(defense * 0.5));

        this.baseStats.health = Math.max(0, this.baseStats.health - actualDamage);
        return { dodged: false, damage: actualDamage };
    }

    heal(amount) {
        const maxHealth = this.getEffectiveStat('maxHealth');
        const oldHealth = this.baseStats.health;
        this.baseStats.health = Math.min(maxHealth, this.baseStats.health + amount);
        return this.baseStats.health - oldHealth;
    }

    fullHeal() {
        this.baseStats.health = this.getEffectiveStat('maxHealth');
        this.statusEffects = [];
    }

    isAlive() {
        return this.baseStats.health > 0;
    }

    die() {
        this.deaths++;
        const goldLoss = Math.floor(this.gold * 0.1);
        this.gold -= goldLoss;
        return { permadeath: false, goldLoss };
    }

    setFlag(flag, value) {
        this.flags[flag] = value;
    }

    getFlag(flag) {
        return this.flags[flag];
    }
}
