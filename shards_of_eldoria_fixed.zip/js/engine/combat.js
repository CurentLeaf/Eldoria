class CombatEngine {
    constructor(game) {
        this.game = game;
        this.inCombat = false;
        this.currentEnemy = null;
        this.turn = 0;
        this.combatLog = [];
    }

    startCombat(enemyId) {
        const enemyData = ENEMIES[enemyId];
        if (!enemyData) return null;

        this.currentEnemy = {
            ...enemyData,
            stats: { ...enemyData.stats },
            currentPhase: 0
        };

        this.inCombat = true;
        this.turn = 0;
        this.combatLog = [];

        this.combatLog.push({
            text: 'Combat begins against ' + this.currentEnemy.name + '!',
            type: 'system'
        });

        return this.currentEnemy;
    }

    playerAttack(skillId) {
        if (!this.inCombat) return null;

        this.turn++;
        const char = this.game.character;
        const enemy = this.currentEnemy;

        let damage = this.calculateDamage(char, enemy);

        const critChance = char.getEffectiveStat('luck') * 0.02;
        let isCrit = Math.random() < critChance;

        if (isCrit) {
            damage = Math.floor(damage * 1.5);
            this.combatLog.push({ text: 'Critical hit! You deal ' + damage + ' damage!', type: 'player_attack' });
        } else {
            this.combatLog.push({ text: 'You attack for ' + damage + ' damage!', type: 'player_attack' });
        }

        enemy.stats.health -= damage;

        if (enemy.stats.health <= 0) {
            return this.endCombat(true);
        }

        return this.enemyTurn();
    }

    enemyTurn() {
        const char = this.game.character;
        const enemy = this.currentEnemy;

        let baseDamage = enemy.stats.strength;
        const result = char.takeDamage(baseDamage);

        if (result.dodged) {
            this.combatLog.push({ text: enemy.name + ' attacks but you dodge!', type: 'enemy_attack' });
        } else {
            this.combatLog.push({ text: enemy.name + ' attacks! ' + result.damage + ' damage!', type: 'enemy_attack' });
        }

        if (char.specialCooldown > 0) {
            char.specialCooldown--;
        }

        if (!char.isAlive()) {
            return this.endCombat(false);
        }

        return {
            success: true,
            ongoing: true,
            playerHealth: char.baseStats.health,
            enemyHealth: enemy.stats.health,
            log: this.combatLog.slice(-5)
        };
    }

    calculateDamage(attacker, defender) {
        let baseDamage = attacker.getEffectiveStat('strength');

        const weaponId = attacker.equipment.weapon;
        if (weaponId) {
            const weapon = WEAPONS[weaponId];
            if (weapon) {
                baseDamage += weapon.damage;
            }
        }

        const defense = defender.stats.defense || 0;
        let damage = Math.max(1, baseDamage - Math.floor(defense * 0.3));
        damage = Math.floor(damage * (0.85 + Math.random() * 0.3));

        return damage;
    }

    attemptFlee() {
        const char = this.game.character;
        const enemy = this.currentEnemy;

        if (enemy.isBoss) {
            this.combatLog.push({ text: 'You cannot flee from a boss battle!', type: 'system' });
            return { success: false, message: 'Cannot flee!' };
        }

        const fleeChance = 0.3 + (char.getEffectiveStat('agility') - enemy.stats.agility) * 0.05;

        if (Math.random() < fleeChance) {
            this.inCombat = false;
            return { success: true, fled: true, message: 'You escaped!' };
        } else {
            this.combatLog.push({ text: 'Failed to escape!', type: 'system' });
            return this.enemyTurn();
        }
    }

    endCombat(victory) {
        this.inCombat = false;
        const char = this.game.character;
        const enemy = this.currentEnemy;

        if (victory) {
            const xpGain = char.addXP(enemy.xpReward);
            const goldGain = enemy.goldReward ? (enemy.goldReward.min + Math.floor(Math.random() * (enemy.goldReward.max - enemy.goldReward.min + 1))) : 10;
            char.gold += goldGain;

            char.killedEnemies[enemy.id] = (char.killedEnemies[enemy.id] || 0) + 1;
            char.totalKills++;

            return {
                success: true,
                victory: true,
                xp: enemy.xpReward,
                gold: goldGain,
                loot: [],
                levelUp: xpGain.leveledUp,
                newLevel: xpGain.newLevel,
                log: this.combatLog
            };
        } else {
            const deathResult = char.die();

            return {
                success: true,
                victory: false,
                permadeath: deathResult.permadeath,
                goldLost: deathResult.goldLoss,
                log: this.combatLog,
                deathMessage: 'Your vision fades to black. The darkness claims another.'
            };
        }
    }
}
