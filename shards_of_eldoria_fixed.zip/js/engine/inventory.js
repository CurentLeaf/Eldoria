class InventoryManager {
    constructor(game) {
        this.game = game;
    }

    addItem(itemId, quantity) {
        const char = this.game.character;
        const item = ITEMS[itemId] || WEAPONS[itemId];

        if (!item) return false;

        if (item.stackable) {
            const existing = char.inventory.find(i => i.id === itemId);
            if (existing) {
                existing.quantity = (existing.quantity || 1) + (quantity || 1);
                return true;
            }
        }

        if (char.inventory.length >= char.maxInventory) {
            return false;
        }

        char.inventory.push({
            id: itemId,
            quantity: quantity || 1
        });

        return true;
    }

    removeItem(itemId, quantity) {
        const char = this.game.character;
        const index = char.inventory.findIndex(i => i.id === itemId);

        if (index === -1) return false;

        const item = char.inventory[index];
        item.quantity = (item.quantity || 1) - (quantity || 1);

        if (item.quantity <= 0) {
            char.inventory.splice(index, 1);
        }

        return true;
    }

    hasItem(itemId, quantity) {
        const char = this.game.character;
        const item = char.inventory.find(i => i.id === itemId);
        return item && (item.quantity || 1) >= (quantity || 1);
    }

    equipItem(itemId, slot) {
        const char = this.game.character;
        const item = ITEMS[itemId] || WEAPONS[itemId];

        if (!item) return { success: false, message: 'Item not found' };

        if (char.equipment[slot]) {
            this.addItem(char.equipment[slot]);
        }

        char.equipment[slot] = itemId;
        this.removeItem(itemId);

        return { success: true };
    }

    getInventoryDisplay() {
        const char = this.game.character;
        return char.inventory.map(invItem => {
            const item = ITEMS[invItem.id] || WEAPONS[invItem.id];
            return {
                ...invItem,
                data: item
            };
        });
    }
}
