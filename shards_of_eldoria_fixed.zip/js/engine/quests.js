class QuestManager {
    constructor(game) {
        this.game = game;
        this.activeQuests = {};
        this.completedQuests = [];
        this.failedQuests = [];
    }

    startQuest(questId) {
        const quest = QUESTS[questId];
        if (!quest) return false;

        if (this.activeQuests[questId] || this.completedQuests.includes(questId)) {
            return false;
        }

        this.activeQuests[questId] = {
            ...quest,
            objectives: quest.objectives.map(obj => ({ ...obj, completed: false }))
        };

        return { success: true, quest: this.activeQuests[questId] };
    }

    updateObjective(questId, objectiveId) {
        const quest = this.activeQuests[questId];
        if (!quest) return false;

        const objective = quest.objectives.find(o => o.id === objectiveId);
        if (!objective) return false;

        objective.completed = true;

        const allComplete = quest.objectives.every(o => o.completed);
        if (allComplete) {
            this.completeQuest(questId);
        }

        return true;
    }

    completeQuest(questId) {
        const quest = this.activeQuests[questId];
        if (!quest) return false;

        if (quest.rewards) {
            if (quest.rewards.xp) {
                this.game.character.addXP(quest.rewards.xp);
            }
            if (quest.rewards.gold) {
                this.game.character.gold += quest.rewards.gold;
            }
        }

        this.completedQuests.push(questId);
        delete this.activeQuests[questId];

        if (quest.nextQuest) {
            this.startQuest(quest.nextQuest);
        }

        return true;
    }

    getActiveQuests(type) {
        const quests = Object.values(this.activeQuests);
        if (type) {
            return quests.filter(q => q.type === type);
        }
        return quests;
    }

    getQuestProgress(questId) {
        const quest = this.activeQuests[questId];
        if (!quest) return null;

        const completed = quest.objectives.filter(o => o.completed).length;
        const total = quest.objectives.length;

        return { quest, completed, total, percent: Math.floor((completed / total) * 100) };
    }

    isQuestCompleted(questId) {
        return this.completedQuests.includes(questId);
    }
}
