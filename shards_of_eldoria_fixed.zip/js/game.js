class Game {
    constructor() {
        this.character = null;
        this.currentNode = null;
        this.combat = null;
        this.inventory = null;
        this.quests = null;
        this.ui = null;
    }

    init() {
        try {
            this.ui = new GameUI(this);
            this.ui.showTitleScreen();

            const savedGame = localStorage.getItem('eldoria_save');
            if (savedGame) {
                this.ui.enableContinueButton();
            }
        } catch (e) {
            console.error('Init error:', e);
            alert('Error: ' + e.message);
        }
    }

    newGame(name, characterClass, difficulty) {
        try {
            console.log('Starting new game:', name, characterClass, difficulty);

            this.character = new Character(name, characterClass, difficulty);
            this.combat = new CombatEngine(this);
            this.inventory = new InventoryManager(this);
            this.quests = new QuestManager(this);

            // Give starting equipment
            const startEquip = CLASS_EQUIPMENT[characterClass];
            if (startEquip) {
                if (startEquip.weapon) {
                    this.inventory.addItem(startEquip.weapon);
                    this.inventory.equipItem(startEquip.weapon, 'weapon');
                }
                if (startEquip.armor) {
                    this.inventory.addItem(startEquip.armor);
                    this.inventory.equipItem(startEquip.armor, 'armor');
                }
                if (startEquip.items) {
                    startEquip.items.forEach(item => this.inventory.addItem(item));
                }
            }

            this.quests.startQuest('main_awakening');
            this.startStoryNode('opening');

        } catch (e) {
            console.error('New game error:', e);
            alert('Error starting game: ' + e.message);
        }
    }

    startStoryNode(nodeId) {
        const node = STORY[nodeId];
        if (!node) {
            console.error('Story node not found:', nodeId);
            this.ui.showMainInterface();
            return;
        }

        this.currentNode = nodeId;
        this.ui.displayStoryNode(node);

        if (node.effects) {
            this.applyEffects(node.effects);
        }
    }

    makeChoice(choiceIndex) {
        const node = STORY[this.currentNode];
        if (!node || !node.choices) return;

        const choice = node.choices[choiceIndex];
        if (!choice) return;

        if (choice.karma) {
            this.character.karma += choice.karma;
        }

        if (choice.combat) {
            this.startCombat(choice.combat, choice.next);
            return;
        }

        if (choice.next) {
            this.startStoryNode(choice.next);
        }
    }

    applyEffects(effects) {
        if (!effects) return;

        if (effects.flag) {
            this.character.setFlag(effects.flag, true);
        }
    }

    startCombat(enemyId, nextNode) {
        const enemy = this.combat.startCombat(enemyId);
        if (!enemy) return;

        this.inCombat = true;
        this.combatNextNode = nextNode || null;
        this.ui.showCombatInterface(enemy);
    }

    playerCombatAction(action, data) {
        if (!this.inCombat) return;

        let result;
        switch(action) {
            case 'attack':
                result = this.combat.playerAttack();
                break;
            case 'flee':
                result = this.combat.attemptFlee();
                break;
        }

        this.ui.updateCombat(result);

        if (result && !result.ongoing) {
            this.endCombat(result);
        }
    }

    endCombat(result) {
        this.inCombat = false;

        if (result.victory) {
            this.ui.showCombatVictory(result);
            if (this.combatNextNode) {
                setTimeout(() => this.startStoryNode(this.combatNextNode), 2000);
            } else {
                setTimeout(() => this.ui.showMainInterface(), 2000);
            }
        } else {
            this.ui.showCombatDefeat(result);
        }
    }

    showQuests() {
        this.ui.showQuestLog(this.quests);
    }

    showInventory() {
        this.ui.showInventory(this.inventory.getInventoryDisplay());
    }

    showCharacter() {
        this.ui.showCharacterSheet(this.character);
    }

    rest() {
        this.character.fullHeal();
        this.ui.showMessage('You rest and recover fully.');
        this.ui.showMainInterface();
    }

    explore(locationId) {
        const location = LOCATIONS[locationId];
        if (!location || !location.enemies || location.enemies.length === 0) {
            this.ui.showMessage('Nothing here right now.');
            return;
        }

        if (Math.random() < 0.6) {
            const enemyId = location.enemies[Math.floor(Math.random() * location.enemies.length)];
            this.startCombat(enemyId);
        } else {
            this.ui.showMessage('You explore but find nothing.');
        }
    }
}

var game;
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing game...');
    game = new Game();
    game.init();
});
