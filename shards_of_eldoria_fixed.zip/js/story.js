const STORY = {
    opening: {
        id: 'opening',
        title: 'Awakening',
        text: `Darkness.

Then pain—a throbbing ache behind your eyes, the taste of blood and dirt in your mouth. Your fingers find cold stone beneath you, slick with something you don't want to identify.

You remember... nothing. Fragments. A village. Screaming. Fire against a midnight sky.

Your body protests as you force yourself upright. You're in a forest clearing, ancient oaks looming overhead like silent judges. The air smells of smoke and something else—decay, perhaps, or the aftermath of violence.

Through the trees, you see an orange glow. Fire. The village burns in the distance.`,
        choices: [
            { text: 'Move toward the burning village', next: 'approach_village' },
            { text: 'Search your belongings first', next: 'search_belongings' }
        ]
    },

    approach_village: {
        id: 'approach_village',
        title: 'The Burning Village',
        text: `You push through the undergrowth toward the flames. The smoke thickens with each step, carrying screams on its bitter breath.

The village of Millbrook burns before you. Half the structures are ablaze. Figures run through the chaos—villagers fleeing, and smaller shapes pursuing them. Goblins.

At the village center, an elderly woman stands defiant. She holds a gnarled staff, and despite her age, there's steel in her stance. Elder Mira, your memory supplies.

Between you and her is chaos—burning buildings and at least a dozen goblins.`,
        choices: [
            { text: 'Fight through to reach Elder Mira', next: 'fight_goblins', combat: 'goblin_scout' },
            { text: 'Look for a weapon first', next: 'find_weapon' }
        ]
    },

    search_belongings: {
        id: 'search_belongings',
        title: 'Taking Stock',
        text: `Before rushing into danger, you check what you have.

Your pouch contains thirty gold coins. Your clothes, though torn, are of decent quality. Around your neck hangs a pendant—a simple circle of silver containing a blue gemstone that seems to pulse with inner light.

The moment your fingers touch it, pain lances through your skull. Images flash: robed figures, dark rituals, a chamber of impossible geometry.

You are a Guardian. The gem is one of five Shards of Eldoria. If they're reunited, the world ends.

You must protect it. At all costs.`,
        choices: [
            { text: 'Head toward the village', next: 'approach_village' }
        ],
        effects: { flag: 'shard_vision' }
    },

    find_weapon: {
        id: 'find_weapon',
        title: 'Armed and Dangerous',
        text: `You scan the chaos for anything useful. Near an overturned cart, you spot a soldier's sword.

Moving quickly, you grab it. The weight feels right in your hand. Your muscles remember this, even if your mind doesn't.

Armed now, you're ready to fight.`,
        choices: [
            { text: 'Fight the goblins', combat: 'goblin_scout', next: 'after_first_combat' }
        ]
    },

    fight_goblins: {
        id: 'fight_goblins',
        text: `You charge toward the goblin, weapon raised!`,
        choices: [
            { text: 'Fight!', combat: 'goblin_scout', next: 'after_first_combat' }
        ]
    },

    after_first_combat: {
        id: 'after_first_combat',
        title: 'First Blood',
        text: `The goblin falls, your blade wet with its blood. Already your breathing has steadied—combat instincts asserting themselves.

More goblins approach. This is just the beginning.`,
        choices: [
            { text: 'Press forward', combat: 'goblin_warrior', next: 'reach_elder' },
            { text: 'Explore the area', next: 'explore_start' }
        ]
    },

    reach_elder: {
        id: 'reach_elder',
        title: 'Elder Mira',
        text: `You fight your way to Elder Mira. She looks at you with ancient, knowing eyes.

"You've returned," she says. "The shard—do you still have it?"

Your hand goes to the pendant beneath your shirt. The gem pulses warm.

"I don't remember much," you admit.

"The goblins came for it," she says. "Their chieftain leads them. You must stop him, or all is lost."`,
        choices: [
            { text: 'Find and defeat the goblin chieftain', combat: 'goblin_chieftain', next: 'victory' },
            { text: 'Rest and prepare first', next: 'explore_start' }
        ]
    },

    victory: {
        id: 'victory',
        title: 'Victory',
        text: `The goblin chieftain falls. The remaining goblins scatter into the night.

Elder Mira approaches, leaning heavily on her staff. "You've saved us. But this is only the beginning. There are four more shards, and dark forces seek them all.

Your journey has just begun, Guardian."`,
        choices: [
            { text: 'Continue your journey', next: 'explore_start' }
        ]
    },

    explore_start: {
        id: 'explore_start',
        title: 'The Road Ahead',
        text: `The immediate danger has passed. The village is safe, for now.

But you know this is only the beginning. Four more shards exist, scattered across Eldoria. Dark forces hunt for them.

You must find them first.`,
        choices: [
            { text: 'Begin your adventure', next: 'main_interface' }
        ]
    },

    main_interface: {
        id: 'main_interface',
        text: 'SHOW_MAIN_INTERFACE'
    }
};

const LOCATIONS = {
    millbrook: {
        name: 'Millbrook (Ruins)',
        description: 'The burned husk of your home village.',
        accessible: true,
        enemies: ['forest_wolf', 'goblin_scout'],
        levelRange: [1, 5]
    },
    dark_forest: {
        name: 'The Dark Forest',
        description: 'Ancient trees block out the sky. Things move in the shadows.',
        accessible: true,
        enemies: ['forest_wolf', 'goblin_scout', 'goblin_warrior'],
        levelRange: [3, 8]
    }
};
