class GameUI {
    constructor(game) {
        this.game = game;
        this.container = document.getElementById('game-container');
    }

    setContent(html) {
        this.container.innerHTML = html;
    }

    showTitleScreen() {
        this.setContent(`
            <div class="title-screen">
                <div class="title-content">
                    <h1 class="game-title">⚔️ Shards of Eldoria ⚔️</h1>
                    <p class="subtitle">A Dark Fantasy RPG</p>
                    <div class="title-buttons">
                        <button class="btn btn-primary btn-large" onclick="game.ui.showNewGameScreen()">New Game</button>
                        <button class="btn btn-secondary btn-large" id="continue-btn" onclick="game.loadGame()" disabled>Continue</button>
                    </div>
                </div>
            </div>
        `);
    }

    enableContinueButton() {
        const btn = document.getElementById('continue-btn');
        if (btn) btn.disabled = false;
    }

    showNewGameScreen() {
        this.setContent(`
            <div class="new-game-screen">
                <h2>Create Your Character</h2>

                <div class="form-group">
                    <label>Name:</label>
                    <input type="text" id="char-name" class="input-field" placeholder="Enter your name" maxlength="20">
                </div>

                <div class="form-group">
                    <label>Class:</label>
                    <div class="class-selection">
                        <div class="class-card selected" data-class="warrior" onclick="game.ui.selectClass('warrior')">
                            <div class="class-icon">⚔️</div>
                            <div class="class-name">Warrior</div>
                            <div class="class-desc">Master of combat. High health and strength.</div>
                        </div>
                        <div class="class-card" data-class="mage" onclick="game.ui.selectClass('mage')">
                            <div class="class-icon">🔮</div>
                            <div class="class-name">Mage</div>
                            <div class="class-desc">Wielder of arcane power. Devastating magic.</div>
                        </div>
                        <div class="class-card" data-class="rogue" onclick="game.ui.selectClass('rogue')">
                            <div class="class-icon">🗡️</div>
                            <div class="class-name">Rogue</div>
                            <div class="class-desc">Swift and deadly. Critical hits.</div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Difficulty:</label>
                    <div class="difficulty-selection">
                        <div class="diff-option selected" data-diff="normal" onclick="game.ui.selectDifficulty('normal')">
                            <strong>Normal</strong>
                            <span>Standard experience</span>
                        </div>
                        <div class="diff-option" data-diff="hard" onclick="game.ui.selectDifficulty('hard')">
                            <strong>Hard</strong>
                            <span>+30% damage taken, +20% XP</span>
                        </div>
                    </div>
                </div>

                <div class="button-row">
                    <button class="btn btn-secondary" onclick="game.ui.showTitleScreen()">Back</button>
                    <button class="btn btn-primary" onclick="game.ui.startNewGame()">Begin Journey</button>
                </div>
            </div>
        `);

        this.selectedClass = 'warrior';
        this.selectedDifficulty = 'normal';
    }

    selectClass(className) {
        document.querySelectorAll('.class-card').forEach(card => card.classList.remove('selected'));
        document.querySelector('.class-card[data-class="' + className + '"]').classList.add('selected');
        this.selectedClass = className;
    }

    selectDifficulty(diff) {
        document.querySelectorAll('.diff-option').forEach(opt => opt.classList.remove('selected'));
        document.querySelector('.diff-option[data-diff="' + diff + '"]').classList.add('selected');
        this.selectedDifficulty = diff;
    }

    startNewGame() {
        const name = document.getElementById('char-name').value.trim() || 'Wanderer';
        console.log('Starting game with:', name, this.selectedClass, this.selectedDifficulty);
        this.game.newGame(name, this.selectedClass, this.selectedDifficulty);
    }

    displayStoryNode(node) {
        if (node.text === 'SHOW_MAIN_INTERFACE') {
            this.showMainInterface();
            return;
        }

        const text = node.text;

        let choicesHtml = '';
        if (node.choices) {
            choicesHtml = '<div class="choices">';
            node.choices.forEach((choice, index) => {
                choicesHtml += '<button class="choice-btn" onclick="game.makeChoice(' + index + ')">' + choice.text + '</button>';
            });
            choicesHtml += '</div>';
        }

        this.setContent(`
            <div class="story-screen">
                ${this.renderHeader()}
                <div class="story-content">
                    ${node.title ? '<h2 class="chapter-title">' + node.title + '</h2>' : ''}
                    <div class="story-text">' + text + '</div>
                    ${choicesHtml}
                </div>
            </div>
        `);
    }

    showCombatInterface(enemy) {
        this.setContent(`
            <div class="combat-screen">
                ${this.renderHeader()}
                <div class="combat-arena">
                    <div class="enemy-section">
                        <div class="enemy-display">
                            <span class="enemy-icon">${enemy.icon}</span>
                            <div class="enemy-info">
                                <h3>${enemy.name}</h3>
                                <div class="health-bar enemy-health">
                                    <div class="health-fill" style="width: 100%"></div>
                                    <span class="health-text">${enemy.stats.health}/${enemy.stats.maxHealth}</span>
                                </div>
                            </div>
                        </div>
                        <p class="enemy-desc">${enemy.description || ''}</p>
                    </div>

                    <div class="combat-log" id="combat-log"></div>

                    <div class="player-section">
                        <div class="health-bar player-health">
                            <div class="health-fill" style="width: ${(this.game.character.baseStats.health / this.game.character.baseStats.maxHealth) * 100}%"></div>
                            <span class="health-text">${this.game.character.baseStats.health}/${this.game.character.baseStats.maxHealth}</span>
                        </div>
                    </div>

                    <div class="combat-actions">
                        <button class="btn btn-danger" onclick="game.playerCombatAction('attack')">⚔️ Attack</button>
                        <button class="btn btn-flee" onclick="game.playerCombatAction('flee')" ${enemy.isBoss ? 'disabled' : ''}>🏃 Flee</button>
                    </div>
                </div>
            </div>
        `);
    }

    updateCombat(result) {
        if (!result) return;

        const log = document.getElementById('combat-log');
        if (log && result.log) {
            log.innerHTML = result.log.map(entry => {
                let className = 'log-entry';
                if (entry.type === 'player_attack') className += ' log-player';
                if (entry.type === 'enemy_attack') className += ' log-enemy';
                return '<div class="' + className + '">' + entry.text + '</div>';
            }).join('');
            log.scrollTop = log.scrollHeight;
        }

        const playerHealth = document.querySelector('.player-health .health-fill');
        const enemyHealth = document.querySelector('.enemy-health .health-fill');

        if (playerHealth) {
            const playerPercent = (this.game.character.baseStats.health / this.game.character.baseStats.maxHealth) * 100;
            playerHealth.style.width = playerPercent + '%';
            document.querySelector('.player-health .health-text').textContent = 
                this.game.character.baseStats.health + '/' + this.game.character.baseStats.maxHealth;
        }

        if (enemyHealth && this.game.combat.currentEnemy) {
            const enemy = this.game.combat.currentEnemy;
            const enemyPercent = (enemy.stats.health / enemy.stats.maxHealth) * 100;
            enemyHealth.style.width = Math.max(0, enemyPercent) + '%';
            document.querySelector('.enemy-health .health-text').textContent = 
                Math.max(0, enemy.stats.health) + '/' + enemy.stats.maxHealth;
        }
    }

    showCombatVictory(result) {
        const content = `
            <div class="combat-result victory">
                <h2>⚔️ Victory! ⚔️</h2>
                <div class="rewards">
                    <p>+${result.xp} XP</p>
                    <p>+${result.gold} Gold</p>
                    ${result.levelUp ? '<p class="level-up">🎉 Level Up! Now level ' + result.newLevel + '!</p>' : ''}
                </div>
                <button class="btn btn-primary" onclick="game.ui.showMainInterface()">Continue</button>
            </div>
        `;

        this.setContent(content);
    }

    showCombatDefeat(result) {
        this.setContent(`
            <div class="combat-result defeat">
                <h2>💀 Defeated 💀</h2>
                <p class="death-message">${result.deathMessage}</p>
                <p>Lost ${result.goldLost} gold.</p>
                <button class="btn btn-primary" onclick="game.ui.showMainInterface()">Continue</button>
            </div>
        `);
    }

    showMainInterface() {
        this.setContent(`
            <div class="main-interface">
                ${this.renderHeader()}

                <div class="main-content">
                    <div class="action-panel">
                        <h3>What would you like to do?</h3>
                        <div class="action-buttons">
                            <button class="btn btn-action" onclick="game.explore('dark_forest')">🌲 Explore the Forest</button>
                            <button class="btn btn-action" onclick="game.showQuests()">📜 Quest Log</button>
                            <button class="btn btn-action" onclick="game.showInventory()">🎒 Inventory</button>
                            <button class="btn btn-action" onclick="game.showCharacter()">👤 Character</button>
                            <button class="btn btn-action" onclick="game.rest()">🏕️ Rest</button>
                        </div>
                    </div>

                    <div class="location-info">
                        <h3>📍 Current Location: Millbrook (Ruins)</h3>
                        <p>The burned remnants of your home village.</p>
                    </div>
                </div>
            </div>
        `);
    }

    renderHeader() {
        const char = this.game.character;
        if (!char) return '';

        return `
            <div class="game-header">
                <div class="char-info">
                    <span class="char-name">${char.name}</span>
                    <span class="char-class">${char.characterClass} Lv.${char.level}</span>
                </div>
                <div class="char-resources">
                    <span class="health">❤️ ${char.baseStats.health}/${char.baseStats.maxHealth}</span>
                    <span class="gold">💰 ${char.gold}</span>
                    <span class="xp">⭐ ${char.xp}/${char.xpToLevel}</span>
                </div>
            </div>
        `;
    }

    showQuestLog(quests) {
        const mainQuests = quests.getActiveQuests('main');

        let questHtml = '<div class="quest-list">';

        if (mainQuests.length > 0) {
            questHtml += '<h3>⚔️ Main Quests</h3>';
            mainQuests.forEach(quest => {
                questHtml += this.renderQuestEntry(quest);
            });
        } else {
            questHtml += '<p class="no-quests">No active quests.</p>';
        }

        questHtml += '</div>';

        this.setContent(`
            <div class="quest-screen">
                ${this.renderHeader()}
                <h2>📜 Quest Log</h2>
                ${questHtml}
                <button class="btn btn-secondary" onclick="game.ui.showMainInterface()">Back</button>
            </div>
        `);
    }

    renderQuestEntry(quest) {
        const progress = this.game.quests.getQuestProgress(quest.id);

        let objectivesHtml = '<ul class="objectives">';
        quest.objectives.forEach(obj => {
            const status = obj.completed ? '✅' : '⬜';
            objectivesHtml += '<li class="' + (obj.completed ? 'completed' : '') + '">' + status + ' ' + obj.text + '</li>';
        });
        objectivesHtml += '</ul>';

        return `
            <div class="quest-entry">
                <div class="quest-header">
                    <h4>${quest.title}</h4>
                    <span class="quest-progress">${progress.completed}/${progress.total}</span>
                </div>
                <p class="quest-desc">${quest.description}</p>
                ${objectivesHtml}
            </div>
        `;
    }

    showInventory(items) {
        const char = this.game.character;

        let inventoryHtml = '<div class="inventory-grid">';
        items.forEach(item => {
            inventoryHtml += `
                <div class="inventory-item">
                    <span class="item-icon">${item.data.icon || '📦'}</span>
                    <span class="item-name">${item.data.name || item.id}</span>
                    ${item.quantity > 1 ? '<span class="item-qty">x' + item.quantity + '</span>' : ''}
                </div>
            `;
        });
        inventoryHtml += '</div>';

        this.setContent(`
            <div class="inventory-screen">
                ${this.renderHeader()}
                <h2>🎒 Inventory (${items.length}/${char.maxInventory})</h2>
                ${inventoryHtml}
                <button class="btn btn-secondary" onclick="game.ui.showMainInterface()">Back</button>
            </div>
        `);
    }

    showCharacterSheet(char) {
        const stats = ['strength', 'intelligence', 'agility', 'vitality', 'luck'];

        let statsHtml = '<div class="stats-grid">';
        stats.forEach(stat => {
            const value = char.getEffectiveStat(stat);
            statsHtml += `
                <div class="stat-row">
                    <span class="stat-name">${stat.toUpperCase()}</span>
                    <span class="stat-value">${value}</span>
                </div>
            `;
        });
        statsHtml += '</div>';

        this.setContent(`
            <div class="character-screen">
                ${this.renderHeader()}
                <h2>👤 ${char.name}</h2>

                <div class="char-overview">
                    <p>Level ${char.level} | ${char.xp}/${char.xpToLevel} XP</p>
                </div>

                <h3>📊 Stats</h3>
                ${statsHtml}

                <h3>📈 Progress</h3>
                <p>Total Kills: ${char.totalKills} | Deaths: ${char.deaths}</p>
                <p>Karma: ${char.karma >= 0 ? '😇' : '😈'} ${char.karma}</p>

                <button class="btn btn-secondary" onclick="game.ui.showMainInterface()">Back</button>
            </div>
        `);
    }

    showMessage(msg) {
        alert(msg);
    }

    showNotification(msg) {
        const notif = document.createElement('div');
        notif.className = 'notification';
        notif.textContent = msg;
        document.body.appendChild(notif);

        setTimeout(function() {
            notif.classList.add('fade-out');
            setTimeout(function() { notif.remove(); }, 500);
        }, 3000);
    }
}
